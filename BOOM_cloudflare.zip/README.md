# BOOM — Cloudflare version

BOOM sekarang sudah dipindahkan dari Express + `ws` + `messages.json` ke Cloudflare Workers + Durable Objects + SQLite.

## Struktur

- `public/index.html` — tampilan BOOM
- `worker.js` — backend WebSocket
- `wrangler.json` — konfigurasi Cloudflare
- Durable Object `BoomRoom` — satu object untuk setiap kode room
- SQLite Durable Object — menyimpan maksimal 200 pesan terakhir per room

## Deploy

1. Buat/login akun Cloudflare.
2. Install Node.js di komputer.
3. Buka terminal di folder ini.
4. Jalankan:

```bash
npm install
npx wrangler login
npx wrangler deploy
```

5. Setelah selesai, Cloudflare akan memberi URL `workers.dev`.
6. Buka URL itu dari HP dan bagikan ke teman.

## Penting

Versi ini tidak memakai Render.

Cloudflare Workers Static Assets menyajikan `public/index.html`, sementara Worker menangani endpoint `/ws`. Durable Objects menangani koneksi WebSocket dan penyimpanan pesan.

Kode room saat ini berfungsi sebagai identitas room, seperti versi Render sebelumnya. Siapa pun yang mengetahui kode tersebut dapat masuk.

## Lokal

```bash
npm install
npm run dev
```

Kemudian buka URL lokal yang diberikan Wrangler.

## Catatan biaya

Konfigurasi ini memakai SQLite-backed Durable Objects, yang tersedia di Workers Free. Free tier tetap punya batas pemakaian harian/bulanan, jadi "gratis" bukan berarti server alam semesta tanpa batas.
