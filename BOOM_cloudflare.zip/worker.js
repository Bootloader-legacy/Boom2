export class BoomRoom {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        text TEXT NOT NULL,
        time TEXT NOT NULL
      )
    `);
  }

  async fetch(request) {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("WebSocket endpoint", { status: 426 });
    }

    const url = new URL(request.url);
    const name = (url.searchParams.get("name") || "").trim().slice(0, 24);
    const room = (url.searchParams.get("room") || "").trim().toUpperCase().slice(0, 32);

    if (!name || !room) {
      return new Response("Nama dan kode room wajib diisi.", { status: 400 });
    }

    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];

    this.ctx.acceptWebSocket(server);
    server.serializeAttachment({ name, room });

    const history = this.ctx.storage.sql
      .exec("SELECT id, name, text, time FROM messages ORDER BY rowid DESC LIMIT 200")
      .toArray()
      .reverse();

    server.send(JSON.stringify({
      type: "joined",
      room,
      name,
      history
    }));

    this.broadcast({
      type: "system",
      text: `${name} masuk ke chat.`
    }, server);

    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(ws, message) {
    let msg;
    try {
      msg = JSON.parse(typeof message === "string" ? message : new TextDecoder().decode(message));
    } catch {
      return;
    }

    const meta = ws.deserializeAttachment() || {};
    if (msg.type !== "chat" || !meta.name) return;

    const text = String(msg.text || "").trim().slice(0, 1000);
    if (!text) return;

    const item = {
      id: crypto.randomUUID(),
      name: meta.name,
      text,
      time: new Date().toISOString()
    };

    this.ctx.storage.sql.exec(
      "INSERT INTO messages (id, name, text, time) VALUES (?, ?, ?, ?)",
      item.id, item.name, item.text, item.time
    );

    this.ctx.storage.sql.exec(`
      DELETE FROM messages
      WHERE rowid NOT IN (
        SELECT rowid FROM messages ORDER BY rowid DESC LIMIT 200
      )
    `);

    this.broadcast({ type: "message", ...item });
  }

  webSocketClose(ws) {
    const meta = ws.deserializeAttachment() || {};
    if (meta.name) {
      this.broadcast({
        type: "system",
        text: `${meta.name} keluar dari chat.`
      }, ws);
    }
  }

  webSocketError(ws) {
    try { ws.close(); } catch {}
  }

  broadcast(payload, except = null) {
    const data = JSON.stringify(payload);
    for (const ws of this.ctx.getWebSockets()) {
      if (ws === except) continue;
      try { ws.send(data); } catch {}
    }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/ws") {
      const room = (url.searchParams.get("room") || "").trim().toUpperCase().slice(0, 32);
      const name = (url.searchParams.get("name") || "").trim().slice(0, 24);

      if (!room || !name) {
        return new Response("Nama dan kode room wajib diisi.", { status: 400 });
      }

      const id = env.BOOM_ROOMS.idFromName(room);
      const stub = env.BOOM_ROOMS.get(id);
      return stub.fetch(request);
    }

    return env.ASSETS.fetch(request);
  }
};
